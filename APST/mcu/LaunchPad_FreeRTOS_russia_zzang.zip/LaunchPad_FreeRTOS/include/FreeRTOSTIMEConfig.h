/*
 * FreeRTOSTIMEConfig.h
 *
 *  Created on: 2016 m�rc. 18
 *      Author: loszi
 */

#ifndef INCLUDE_FREERTOSTIMECONFIG_H_
#define INCLUDE_FREERTOSTIMECONFIG_H_

#define configTIME_START_EPOCH_TIME		1451606400			/* 2016.01.01 */
#define configTIME_TIME_ZONE			1					/* GMT+1 */

#endif /* INCLUDE_FREERTOSTIMECONFIG_H_ */
