RPLIDAR Public SDK v1.10.0 Release Note
======================================

- [new feature] support Rplidar S1
