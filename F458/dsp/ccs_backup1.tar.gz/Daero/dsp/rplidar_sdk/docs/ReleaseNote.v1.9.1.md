RPLIDAR Public SDK v1.9.1 Release Note
======================================

- [improvement] updated license declarations of RPLIDAR Public SDK
